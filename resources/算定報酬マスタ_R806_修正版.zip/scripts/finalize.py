import json, re, sys, csv, collections
J = json.load(open(sys.argv[1])); raw = J['rows']; pagebase = {int(k): v for k, v in J['pagebase'].items()}
outdir = sys.argv[2]

SERVICE_TARGET = {  # サービス → (対象区分, 根拠)
    '短期入所サービス費': ('その他', '人員基準にサービス管理責任者の配置規定なし（元CSVは「サビ管関連（別途確認）」）'),
    '重度障害者等包括支援サービス費': ('その他', '配置するのはサービス提供責任者（元CSVは「サビ管関連（別途確認）」）'),
    '就労選択支援サービス費': ('その他', '個別支援計画不要のためサービス管理責任者の配置不要（元CSVは「サビ管」）'),
}
OTHER = {'居宅介護サービス費', '重度訪問介護サービス費', '同行援護サービス費', '行動援護サービス費', '計画相談支援給付費',
         '障害児相談支援給付費', '地域相談支援給付費（地域移行支援）', '地域相談支援給付費（地域定着支援）'}
def target(svc):
    if svc in SERVICE_TARGET: return SERVICE_TARGET[svc]
    if svc in OTHER: return ('その他', '')
    if '児' in svc or '放課後' in svc or '保育所' in svc: return ('児発管', '')
    return ('サビ管', '')

def clean_lab(s):
    s = re.sub(r'^注(?=[^\d])', '', s.strip()).strip()
    s = re.sub(r'[\s+]+$', '', s)
    return s

def unit_of(*texts):
    for t in texts:
        m = re.search(r'(\d+)?(日|月|回|片道)(につき|当たり)', t or '')
        if m: return m.group(2)
        if re.search(r'1日当たり|日当たり', t or ''): return '日'
    return ''

def summarize(cov, allb=()):
    if not cov: return ''
    if len(cov) == 1: return ' > '.join(cov[0])
    common = []
    for parts in zip(*cov):
        if len(set(parts)) == 1: common.append(parts[0])
        else: break
    if common:
        n = len(common)
        under = [p for p in allb if p[:n] == common]
        if under and len(under) <= len(cov): return ' > '.join(common)
        nxt = []
        for p in cov:
            if len(p) > n and p[n] not in nxt: nxt.append(p[n])
        return ' > '.join(common) + ' > ' + '・'.join(nxt) if len(nxt) <= 8 else ' > '.join(common) + f'（{len(cov)}区分）'
    firsts = []
    for p in cov:
        if p and p[0] not in firsts: firsts.append(p[0])
    return ' / '.join(firsts)

UT = re.compile(r'([+\-]?)\s*(\d[\d,]*)\s*単位')
RT = re.compile(r'([×+\-]?)\s*(\d[\d,.]*)\s*/\s*(1,000|1000|100)')

# サービス一覧
svcs = []; 
for r in raw:
    if r['service'] not in [s['サービス種別'] for s in svcs]:
        svcs.append({'サービス種別': r['service'], 'pages': []})
for s in svcs:
    ps = sorted({r['page'] for r in raw if r['service'] == s['サービス種別']})
    s['pages'] = ps
services = []
for i, s in enumerate(svcs, 1):
    t, why = target(s['サービス種別'])
    services.append(dict(サービスID=f'S{i:02d}', サービス種別=s['サービス種別'], 対象区分=t, 対象区分の根拠=why,
                         PDF開始ページ=min(s['pages']), PDF終了ページ=max(s['pages']), 資料内開始ページ=min(s['pages']) - 1))
sid = {s['サービス種別']: s['サービスID'] for s in services}
tgt = {s['サービス種別']: s['対象区分'] for s in services}

rows = []
for r in raw:
    lab = clean_lab(r['label'])
    path = [clean_lab(p) for p in r['path'] if clean_lab(p)]
    cond = clean_lab(r.get('cond', ''))
    if cond and cond not in lab:
        lab = (lab + ' ' + cond).strip() if lab else cond
    if r['zone'] == '注欄':
        name = r['header']; levels = []
    elif path:
        name = path[0]; levels = path[1:]
    else:
        name = clean_lab(r['label']) or lab; levels = []
        lab = cond if clean_lab(r['label']) else ''
    if lab == name: lab = ''
    blob = ' '.join([name, ' '.join(levels), lab])
    expr = r['expr']
    us = UT.findall(expr); rs = RT.findall(expr)
    # 分類
    if '減算' in blob: cls = '減算'
    elif '加算' in blob: cls = '加算'
    elif r['zone'] == '基本部分': cls = '基本報酬'
    elif r['zone'] == '枠外' and re.search(r'(サービス費|給付費|支援費|援助費|介護費)', name) and not rs and not (us and us[0][0]): cls = '基本報酬'
    else: cls = '注による調整'
    # 増減
    if rs:
        op, a, b = rs[0]; a = float(a.replace(',', '')); b = int(b.replace(',', '')); op = op or '×'
        if op == '×': direction = '減額' if a < b else ('増額' if a > b else '変更なし')
        else: direction = '減額' if op == '-' else '増額'
        if op == '×' and re.search(r'[+]\s*所定単位(数)?\s*×', expr): direction = '増額'
    elif us:
        direction = '減額' if (us[0][0] == '-' or 'を減算' in expr) else ('基本' if cls == '基本報酬' else '増額')
    else: direction = ''
    ratio_op = rs[0][0] or ('+' if rs and cls == '加算' else '') if rs else ''
    rows.append({
        'サービスID': sid[r['service']], 'サービス種別': r['service'], '対象区分': tgt[r['service']],
        '分類': cls, '増減': direction, '算定項目名': name,
        '区分_階層': ' > '.join(levels), '区分_条件': lab,
        '区分・条件': ' > '.join([x for x in levels + [lab] if x]),
        '適用範囲': ((summarize(r['cover'], pagebase.get(r['page'], [])) + (' > ' + r['band'] if r.get('band') else '')) if r['zone'] == '注欄' else ''),
        '計算式原文': expr,
        '単位数': int(us[0][1].replace(',', '')) if us else '',
        '単位数_増分': int(us[1][1].replace(',', '')) if len(us) > 1 and 'ごとに' in expr else '',
        '割合_演算': ('+×' if rs and re.search(r'[+]\s*所定単位(数)?\s*×', expr) else (rs[0][0] if rs else '')), '割合_分子': (rs[0][1].replace(',', '')) if rs else '',
        '割合_分母': int(rs[0][2].replace(',', '')) if rs else '',
        '算定単位': unit_of(expr, lab, name, ' '.join(levels)),
        '令和8年度見直し': 1 if r['red'] else 0,
        '表内位置': r['zone'], 'PDFページ': r['page'], '資料内ページ': r['page'] - 1,
        'PDF座標X': r['x'], 'PDF座標Y': r['y'], 'セル範囲': ','.join(str(v) for v in r['cell']),
        '備考': ' '.join(x for x in [r.get('note', ''), r['rest']] if x),
    })
ZR = {'基本部分': 0, '注欄': 1, '枠外': 2}
rows.sort(key=lambda x: (x['PDFページ'], ZR[x['表内位置']], float(x['セル範囲'].split(',')[1]), float(x['セル範囲'].split(',')[0]), x['PDF座標Y'], x['PDF座標X']))
for i, x in enumerate(rows, 1): x['マスタID'] = f'R806-{i:05d}'
# 旧マスタIDとの対応(同一ページ・旧座標が新セル内・数値が一致)
if len(sys.argv) > 3:
    import unicodedata
    def tk(s):
        s = unicodedata.normalize('NFKC', s)
        return set(re.findall(r'\d[\d,.]*', s))
    old = list(csv.DictReader(open(sys.argv[3], encoding='utf-8-sig')))
    byp = collections.defaultdict(list)
    for o in old: byp[int(o['PDFページ'])].append(o)
    used = set()
    for x in rows:
        x0, t0, x1, b0 = map(float, x['セル範囲'].split(','))
        nt = tk(x['計算式原文'])
        ids = []
        for o in byp[x['PDFページ']]:
            ox, oy = float(o['PDF座標X']), float(o['PDF座標Y'])
            if x0 - 2 <= ox <= x1 + 2 and t0 - 3 <= oy <= b0 + 2 and nt & tk(o['計算式・単位数（PDF原文）']):
                if abs(oy - x['PDF座標Y']) < 4 or len(nt & tk(o['計算式・単位数（PDF原文）'])) == len(nt):
                    ids.append(o['マスタID'])
        x['旧マスタID'] = ';'.join(ids); used.update(ids)
    # 未対応の旧行: 同一ページで同じ数値を持つ最も近い新行に対応付け
    for o in old:
        if o['マスタID'] in used: continue
        ot = tk(o['計算式・単位数（PDF原文）']); ox, oy = float(o['PDF座標X']), float(o['PDF座標Y'])
        cands = [x for x in rows if x['PDFページ'] == int(o['PDFページ']) and ot and ot <= tk(x['計算式原文'])]
        if cands:
            x = min(cands, key=lambda x: abs(x['PDF座標X'] - ox) + abs(x['PDF座標Y'] - oy))
            if abs(x['PDF座標X'] - ox) + abs(x['PDF座標Y'] - oy) < 40:
                x['旧マスタID'] = ';'.join([i for i in x['旧マスタID'].split(';') if i] + [o['マスタID']]); used.add(o['マスタID'])
    print('old mapped', len(used), '/', len(old))
cols = ['マスタID'] + [k for k in rows[0] if k != 'マスタID']
with open(f'{outdir}/算定報酬マスタ_R806.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
with open(f'{outdir}/サービス一覧_R806.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(services[0])); w.writeheader(); w.writerows(services)
print(len(rows), collections.Counter(x['分類'] for x in rows), collections.Counter(x['増減'] for x in rows))
