-- 算定報酬マスタ（令和8年6月版 報酬算定構造）SQLiteスキーマ
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS services (
    service_id        TEXT PRIMARY KEY,           -- サービスID (S01..)
    service_name      TEXT NOT NULL UNIQUE,       -- サービス種別
    target_role       TEXT NOT NULL CHECK (target_role IN ('サビ管','児発管','その他')), -- 対象区分
    target_role_note  TEXT,                       -- 対象区分の根拠
    pdf_page_start    INTEGER NOT NULL,           -- PDF開始ページ
    pdf_page_end      INTEGER NOT NULL,           -- PDF終了ページ
    doc_page_start    INTEGER NOT NULL            -- 資料内開始ページ
);

CREATE TABLE IF NOT EXISTS fee_items (
    master_id         TEXT PRIMARY KEY,           -- マスタID (R806-00001..)
    service_id        TEXT NOT NULL REFERENCES services(service_id),
    category          TEXT NOT NULL CHECK (category IN ('基本報酬','加算','減算','注による調整')), -- 分類
    direction         TEXT CHECK (direction IN ('基本','増額','減額','変更なし')),             -- 増減
    item_name         TEXT NOT NULL,              -- 算定項目名
    condition_levels  TEXT,                       -- 区分_階層（" > " 区切り）
    condition_detail  TEXT,                       -- 区分_条件（セル内の条件）
    condition_text    TEXT,                       -- 区分・条件（表示用）
    applies_to        TEXT,                       -- 適用範囲（注欄の値が適用される基本部分）
    expression        TEXT NOT NULL,              -- 計算式原文
    units             INTEGER,                    -- 単位数
    units_increment   INTEGER,                    -- 単位数_増分（「〜ごとに＋N単位」のN）
    rate_op           TEXT,                       -- 割合_演算（× / + / - / +×=所定単位×率を加算）
    rate_num          REAL,                       -- 割合_分子
    rate_den          INTEGER,                    -- 割合_分母
    calc_unit         TEXT,                       -- 算定単位（日/月/回/片道）
    revised_r8        INTEGER NOT NULL CHECK (revised_r8 IN (0,1)), -- 令和8年度見直し（赤字）
    table_zone        TEXT NOT NULL,              -- 表内位置（基本部分/注欄/枠外）
    pdf_page          INTEGER NOT NULL,
    doc_page          INTEGER NOT NULL,
    pdf_x             REAL,
    pdf_y             REAL,
    cell_bbox         TEXT,                       -- セル範囲 x0,top,x1,bottom
    note              TEXT,                       -- 備考
    legacy_master_ids TEXT                        -- 旧マスタID（; 区切り）
);

CREATE INDEX IF NOT EXISTS idx_fee_items_service  ON fee_items(service_id);
CREATE INDEX IF NOT EXISTS idx_fee_items_category ON fee_items(category);
CREATE INDEX IF NOT EXISTS idx_fee_items_name     ON fee_items(item_name);

-- 日本語の列名で見るためのビュー
CREATE VIEW IF NOT EXISTS v_算定報酬マスタ AS
SELECT f.master_id AS マスタID, s.service_name AS サービス種別, s.target_role AS 対象区分,
       f.category AS 分類, f.direction AS 増減, f.item_name AS 算定項目名,
       f.condition_text AS 区分・条件, f.applies_to AS 適用範囲, f.expression AS 計算式原文,
       f.units AS 単位数, f.units_increment AS 単位数_増分,
       f.rate_op AS 割合_演算, f.rate_num AS 割合_分子, f.rate_den AS 割合_分母,
       f.calc_unit AS 算定単位, f.revised_r8 AS 令和8年度見直し,
       f.pdf_page AS PDFページ, f.doc_page AS 資料内ページ, f.note AS 備考
FROM fee_items f JOIN services s USING (service_id);
