"""CSV → SQLite 取り込み
使い方: python import_sqlite.py [出力先.sqlite]
同じフォルダの schema.sql / r806_services.csv / r806_fee_master.csv を読む。
"""
import csv, sqlite3, sys
from pathlib import Path

here = Path(__file__).parent
db_path = Path(sys.argv[1]) if len(sys.argv) > 1 else here / 'r806.sqlite'

SERVICE_COLS = {'サービスID': 'service_id', 'サービス種別': 'service_name', '対象区分': 'target_role',
                '対象区分の根拠': 'target_role_note', 'PDF開始ページ': 'pdf_page_start',
                'PDF終了ページ': 'pdf_page_end', '資料内開始ページ': 'doc_page_start'}
ITEM_COLS = {'マスタID': 'master_id', 'サービスID': 'service_id', '分類': 'category', '増減': 'direction',
             '算定項目名': 'item_name', '区分_階層': 'condition_levels', '区分_条件': 'condition_detail',
             '区分・条件': 'condition_text', '適用範囲': 'applies_to', '計算式原文': 'expression',
             '単位数': 'units', '単位数_増分': 'units_increment', '割合_演算': 'rate_op',
             '割合_分子': 'rate_num', '割合_分母': 'rate_den', '算定単位': 'calc_unit',
             '令和8年度見直し': 'revised_r8', '表内位置': 'table_zone', 'PDFページ': 'pdf_page',
             '資料内ページ': 'doc_page', 'PDF座標X': 'pdf_x', 'PDF座標Y': 'pdf_y',
             'セル範囲': 'cell_bbox', '備考': 'note', '旧マスタID': 'legacy_master_ids'}

def load(con, csv_name, table, cols):
    with open(here / csv_name, encoding='utf-8-sig', newline='') as f:
        rows = [{cols[k]: (v if v != '' else None) for k, v in r.items() if k in cols} for r in csv.DictReader(f)]
    names = list(cols.values())
    con.executemany(f'INSERT INTO {table} ({",".join(names)}) VALUES ({",".join("?" * len(names))})',
                    [[r.get(n) for n in names] for r in rows])
    return len(rows)

if db_path.exists(): db_path.unlink()
con = sqlite3.connect(db_path)
con.executescript((here / 'schema.sql').read_text(encoding='utf-8'))
n1 = load(con, 'r806_services.csv', 'services', SERVICE_COLS)
n2 = load(con, 'r806_fee_master.csv', 'fee_items', ITEM_COLS)
con.commit()
print(f'{db_path}: services={n1}, fee_items={n2}')
