"""PDFの罫線(細い塗り矩形)からセルを復元し、文字をセルに割り当てる"""
import pdfplumber, numpy as np, unicodedata, re, collections

def _n1(ch):
    o = ord(ch)
    if 0xFF01 <= o <= 0xFF5E: return chr(o - 0xFEE0)
    if ch in '\u3000\xa0': return ' '
    return {'−': '-', '－': '-', '‐': '-'}.get(ch, ch)
def N(s): return ''.join(_n1(c) for c in s)   # 1文字→1文字の正規化(位置を保つ)

def is_red(c):
    col = c.get('non_stroking_color')
    return isinstance(col, (list, tuple)) and len(col) == 3 and col[0] > 0.6 and col[1] < 0.4 and col[2] < 0.4

def segments(page):
    H, V = [], []
    for r in page.rects:
        col = r.get('non_stroking_color')
        if col == (1.0, 1.0, 1.0) or col == [1.0, 1.0, 1.0]: continue
        w, h = r['width'], r['height']
        if h < 1.5 and w > 1.5: H.append((r['x0'], r['x1'], (r['top'] + r['bottom']) / 2))
        elif w < 1.5 and h > 1.5: V.append((r['top'], r['bottom'], (r['x0'] + r['x1']) / 2))
    return np.array(H).reshape(-1, 3), np.array(V).reshape(-1, 3)

def cell_of(px, py, H, V, W, Ht, tol=0.8):
    # 左右の縦線
    m = (V[:, 0] - tol <= py) & (V[:, 1] + tol >= py)
    xs = V[m, 2]
    l = xs[xs <= px].max() if (xs <= px).any() else 0.0
    r = xs[xs > px].min() if (xs > px).any() else W
    m = (H[:, 0] - tol <= px) & (H[:, 1] + tol >= px)
    ys = H[m, 2]
    t = ys[ys <= py].max() if (ys <= py).any() else 0.0
    b = ys[ys > py].min() if (ys > py).any() else Ht
    return (round(float(l), 1), round(float(t), 1), round(float(r), 1), round(float(b), 1))

class Cell:
    def __init__(self, bbox): self.bbox = bbox; self.chars = []
    x0 = property(lambda s: s.bbox[0]); top = property(lambda s: s.bbox[1])
    x1 = property(lambda s: s.bbox[2]); bottom = property(lambda s: s.bbox[3])
    def finalize(self):
        cs = sorted(self.chars, key=lambda c: (c['top'], c['x0']))
        lines = []
        for c in cs:
            if lines and abs(lines[-1][-1]['top'] - c['top']) < 2.0: lines[-1].append(c)
            else: lines.append([c])
        # 行内はx順
        self.lines = [sorted(l, key=lambda c: c['x0']) for l in lines]
        # 右寄せの値がラベルの折返しの途中に入る場合、値をラベルの最終行の後ろへ移す
        VO = re.compile(r'\s*[(]?\s*[+]?\s*[\d,]+\s*単位\s*[)]?\s*')
        HASV = re.compile(r'単位|/\s*\d')
        txt = lambda cs: N(''.join(c['text'] for c in cs))
        L = self.lines
        for i in range(len(L) - 1):
            ln = L[i]
            if len(ln) < 2: continue
            # x方向の切れ目で分割
            k = max(range(1, len(ln)), key=lambda j: ln[j]['x0'] - ln[j - 1]['x1'])
            if ln[k]['x0'] - ln[k - 1]['x1'] < 3: continue
            left, right = ln[:k], ln[k:]
            if not VO.fullmatch(txt(right)) or HASV.search(txt(left)): continue
            j = i + 1
            if j < len(L) and not HASV.search(txt(L[j])) and L[j][0]['x0'] >= left[0]['x0'] - 15 \
               and L[j][-1]['x1'] < right[0]['x0'] and not re.match(r'\s*([(][\d一二三四五六七八九十]+[)]|区分|[イロハニホヘト])', txt(L[j])):
                L[i] = left; L[j] = L[j] + right
        self.lines = L
        # セル内が「左:名称・注記」「右:値」の2列で、行が揃っていない場合は左→右の順に並べ替える
        segs = []
        for li, ln in enumerate(self.lines):
            cur = [ln[0]]
            for a, b in zip(ln, ln[1:]):
                if b['x0'] - a['x1'] > 8: segs.append((li, cur)); cur = [b]
                else: cur.append(b)
            segs.append((li, cur))
        if len(segs) >= 4:
            xs = sorted(sg[1][0]['x0'] for sg in segs)
            gapi = max(range(1, len(xs)), key=lambda i: xs[i] - xs[i - 1])
            if xs[gapi] - xs[gapi - 1] > 20:
                split = (xs[gapi] + xs[gapi - 1]) / 2
                left = [sg for sg in segs if sg[1][0]['x0'] < split]
                right = [sg for sg in segs if sg[1][0]['x0'] >= split]
                lt = lambda sg: N(''.join(c['text'] for c in sg[1]))
                if len(left) >= 2 and len(right) >= 2 and not any(HASV.search(lt(sg)) for sg in left) \
                   and sum(bool(HASV.search(lt(sg))) for sg in right) >= 2:
                    leftlines = {sg[0] for sg in left}
                    shared = sum(1 for sg in right if sg[0] in leftlines)
                    if shared < len(right) / 2:
                        self.lines = [sg[1] for sg in left] + [sg[1] for sg in right]
        self.seq = [c for l in self.lines for c in l]   # 読み順の文字列
        self.text = ''.join(N(c['text']) for c in self.seq)
        self.raw = ''.join(c['text'] for c in self.seq)
        return self

def page_cells(page):
    H, V = segments(page)
    W, Ht = float(page.width), float(page.height)
    cells = {}
    for c in page.chars:
        if not c['text'].strip(): continue
        cx, cy = (c['x0'] + c['x1']) / 2, (c['top'] + c['bottom']) / 2
        bb = cell_of(cx, cy, H, V, W, Ht)
        cells.setdefault(bb, Cell(bb)).chars.append(c)
    return [cl.finalize() for cl in cells.values()]
