"""報酬算定構造PDF → 算定報酬マスタ(セル単位で再構築)"""
import sys, re, json, collections
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import pdfplumber, cells as C

TOK = re.compile(r'[×+\-]?\s*\d[\d,.]*\s*/\s*(?:1,000|1000|100)|[+\-]?\s*\d[\d,]*\s*単位')
EXPR_PAT = [re.compile(p) for p in [r'\d+人\d+日当たり', r'\d+(日|月|回)につき', r'月\d+回を限度として', r'所定単位', r'1日当たり']]

def clean(s):
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def split_rows(cell):
    """セル内テキストを (ラベル, 式, 式の開始,終了位置) の行に分割"""
    t = cell.text
    toks = [m for m in TOK.finditer(t)]
    if not toks: return [], t
    groups = []
    for m in toks:
        if groups:
            gap = t[groups[-1][-1].end():m.start()]
            if ('ごとに' in gap and len(gap) < 40 and not re.search(r'[イロハニホヘ](所要|\()', gap)) or re.fullmatch(r'\s*', gap):
                groups[-1].append(m); continue
        groups.append([m])
    rows = []; pos = 0
    for gi, g in enumerate(groups):
        gs, ge = g[0].start(), g[-1].end()
        gap = t[pos:gs]
        # ギャップ内で式の開始位置を探す(括弧の外 or 閉じていない括弧)
        depth = 0; opens = []; cand = []
        for i, ch in enumerate(gap):
            if ch == '(': opens.append(i); depth += 1
            elif ch == ')' and opens: opens.pop(); depth -= 1
        if opens: cand.append(opens[0])
        # 括弧の外にあるパターン
        inside = [0] * (len(gap) + 1); d = 0
        for i, ch in enumerate(gap):
            if ch == '(': d += 1
            inside[i] = d
            if ch == ')' and d > 0: d -= 1
        for p in EXPR_PAT:
            for mm in p.finditer(gap):
                if inside[mm.start()] == 0 or (opens and mm.start() > opens[0]): cand.append(mm.start())
        es = min(cand) if cand else len(gap)
        label = gap[:es]; exs = pos + es
        if not label.strip():
            inner = t[exs:gs].lstrip('( ')
            inner = re.sub(r'\s*[:：].*$', '', inner)
            if len(inner) >= 4 and not any(p.match(inner) for p in EXPR_PAT):
                label = inner
        # 式の終端
        end = ge
        nxt = groups[gi + 1][0].start() if gi + 1 < len(groups) else len(t)
        tail = t[end:nxt]
        expr_open = t[exs:ge].count('(') - t[exs:ge].count(')')
        if expr_open > 0:
            k = tail.find(')')
            while k >= 0 and expr_open > 1:
                k2 = tail.find(')', k + 1); expr_open -= 1; k = k2
            if k >= 0: end += k + 1
        else:
            mm0 = re.match(r'\s*/\s*(日|月|回)', tail)
            if mm0: end += len(mm0.group(0)); tail = tail[len(mm0.group(0)):]
            mm = re.match(r'\s*(を限度として|を)?(加算|減算)?(した単位数)?\s*\)?', tail)
            if mm and mm.group(0).strip() and (mm.group(0).count(')') == 0 or t[exs:ge].count('(') > t[exs:ge].count(')')):
                end += len(mm.group(0).rstrip(')')) if mm.group(0).count(')') else mm.group(0).__len__()
        note = ''
        lab_c = clean(label)
        if re.fullmatch(r'\(.*\)', lab_c) and ('限度' in lab_c or 'それぞれ' in lab_c):
            note = lab_c; label = ''
        mc = re.match(r'\(([^:()]{1,40}(?:\([^()]*\))?[^:()]{0,20})[:：]', t[exs:ge])
        cond = clean(mc.group(1)) if mc else ''
        rows.append(dict(label=label, s=exs, e=end, cond=cond, note=note, toks=[(x.start(), x.end(), x.group()) for x in g]))
        pos = end
    rest = t[pos:]
    return rows, rest

def label_of(cell):
    rows, rest = split_rows(cell)
    if rows: return clean(rows[0]['label']) or clean(cell.text[:rows[0]['s']])
    m = TOK.search(cell.text)
    s = cell.text[:m.start()] if m else cell.text
    s = re.sub(r'\(\s*$', '', s)
    return clean(s)

MKL = re.compile(r'^\s*(イ|ロ|ハ|ニ|ホ|ヘ|ト|\(\d+\)|\([一二三四五六七八九十]+\))')
def label_at(cell, y):
    groups = []
    for ln in cell.lines:
        t = C.N(''.join(c['text'] for c in ln))
        if MKL.match(t) or not groups: groups.append([ln[0]['top'], t])
        else: groups[-1][1] += t
    if len(groups) >= 2:
        cand = [g for g in groups if g[0] <= y + 1]
        g = cand[-1] if cand else groups[0]
        txt = g[1]
        m = TOK.search(txt)
        return clean(txt[:m.start()] if m else txt).rstrip('(')
    return label_of(cell)

def run(pdf_path):
    pdf = pdfplumber.open(pdf_path)
    out = []; diag = []; global pagebase; pagebase = {}
    svc = None; hdr = None   # hdr: dict(cols=[(x0,x1,text)], base_x1, x0)
    carry = {}
    for pno, page in enumerate(pdf.pages, 1):
        if pno == 1: continue
        H, V = C.segments(page)
        cs = C.page_cells(page)
        W, Ht = float(page.width), float(page.height)
        bymap = {c.bbox: c for c in cs}
        title = [c for c in cs if c.text.startswith('○')]
        if title:
            svc = clean(title[0].raw.lstrip('○'))
            carry = {}
        notes = [c for c in cs if c.text.strip() == '注']
        if notes:
            band_top = min(c.top for c in notes)
            heads = [c for c in cs if c.top >= band_top - 1 and c.top <= max(n.bottom for n in notes) + 1 and c.text.strip() != '注' and not c.text.startswith('○')]
            kihon = [c for c in heads if '基本部分' in c.text]
            heads = [c for c in heads if c.text.strip() != '又は']
            band_bot = kihon[0].bottom if kihon else sorted(c.bottom for c in heads)[len(heads) // 2]
            # ヘッダ帯のセル(注の下に積まれたもの)を全部
            band = [c for c in cs if c.top >= band_top - 1 and c.bottom <= band_bot + 1 and c.text.strip() != '注' and not c.text.startswith('○')]
            base_x1 = kihon[0].x1 if kihon else min(n.x0 for n in notes) - 1
            hdr = dict(band=[(c.x0, c.x1, c.top, clean(c.raw)) for c in band if c.x0 >= base_x1 - 1],
                       base_x1=base_x1, x0=kihon[0].x0 if kihon else 0, band_bot=band_bot,
                       cols=sorted({(n.x0, n.x1) for n in notes}))
            main_top = band_bot
        else:
            main_top = None
        body = [c for c in cs if not c.text.startswith('○') and c.text.strip() != '又は' and (main_top is None or c.top >= main_top - 1)]
        base_x1 = hdr['base_x1'] if hdr else W
        def in_table_y(y):
            if not hdr: return False
            cols = hdr['cols']; n = 0
            for (cx0, cx1) in cols:
                m = (abs(V[:, 2] - cx0) < 2.5) & (V[:, 0] - 1 <= y) & (V[:, 1] + 1 >= y)
                n += bool(m.any())
            return n >= max(2, 0.5 * len(cols))
        is_cont = main_top is None
        page_top = min((c.top for c in body), default=0)
        tcells = [c for c in body if in_table_y((c.top + c.bottom) / 2)]
        mt = min((c.top for c in tcells), default=None)
        if main_top is not None and mt is not None: mt = max(mt, main_top)
        main_bottom = max((c.bottom for c in tcells), default=None)
        def in_main(c): return c in tset
        tset = set(tcells)
        def left_path(c, cy, xmin):
            """セルの左側にあるセルを右→左にたどってラベル列を返す"""
            path = []; x = c.x0 - 1.5
            while x > xmin:
                bb = C.cell_of(x, cy, H, V, W, Ht)
                if bb[2] <= xmin + 0.5 or bb[0] >= c.x0: break
                lc = bymap.get(bb)
                key = (round(bb[0]), round(bb[2]))
                if lc is not None:
                    lab = label_at(lc, cy)
                    path.append(lab)
                else:
                    # 空セル: 前ページから続くなら引き継ぐ
                    if bb[1] <= page_top + 2 and key in carry: path.append(carry[key])
                x = bb[0] - 1.5
            return list(reversed([p for p in path if p]))
        def base_path_at(y):
            class P: pass
            pc = P(); pc.x0 = base_x1 + 0.5
            p = left_path(pc, y, (hdr['x0'] - 1) if hdr else 0)
            return p
        def header_for(c):
            cx = (c.x0 + c.x1) / 2
            # 表の途中に置かれた小見出し(数値なしのセル)が直上にあればそれを優先
            lim = (main_top if main_top is not None else -1)
            above = [s for s in body if s.x0 - 1 <= cx <= s.x1 + 1 and s.bottom <= c.top + 1 and s.top > lim + 1 and s is not c]
            if above:
                s = max(above, key=lambda s: s.bottom)
                if not TOK.search(s.text) and s.text.strip() not in ('又は', '注') and len(s.text.strip()) >= 4 and c.top - s.bottom < 40:
                    return clean(s.raw)
            hs = [h for h in hdr['band'] if h[0] - 1 <= cx <= h[1] + 1]
            hs.sort(key=lambda h: h[2])
            return ' '.join(h[3] for h in hs)
        # 主表の基本部分の行(適用範囲の算出用)
        base_rows = []
        for c in body:
            if in_main(c) and c.x1 <= base_x1 + 1 and TOK.search(c.text):
                cy = (c.top + c.bottom) / 2
                base_rows.append((cy, left_path(c, cy, hdr['x0'] - 1 if hdr else 0) + [label_of(c)]))
        pagebase[pno] = [p for y, p in base_rows]
        for c in sorted(body, key=lambda c: (c.top, c.x0)):
            rows, rest = split_rows(c)
            if not rows: continue
            cy = (c.top + c.bottom) / 2
            if in_main(c) and c.x0 >= base_x1 - 1 and hdr and any(c.x0 >= h[0] - 2 and c.x1 <= h[1] + 2 for h in hdr['band']):
                zone = '注欄'; head = header_for(c)
                ys = [y for y, p in base_rows if c.top - 0.5 <= y <= c.bottom + 0.5] + [cy]
                cov = []
                for y in sorted(ys):
                    p = base_path_at(y)
                    if p and p not in cov: cov.append(p)
                path = []
            elif in_main(c) and c.x1 <= base_x1 + 1:
                zone = '基本部分'; head = ''
                path = left_path(c, cy, (hdr['x0'] - 1) if hdr else 0); cov = []
            elif hdr and c.x0 >= base_x1 - 1 and any(c.x0 >= h[0] - 2 and c.x1 <= h[1] + 2 for h in hdr['band']) and not TOK.search(label_of(c) or 'x') is None and False:
                pass
            elif hdr and c.x0 >= base_x1 - 1 and any(c.x0 >= h[0] - 2 and c.x1 <= h[1] + 2 for h in hdr['band']):
                zone = '注欄'; head = header_for(c); path = []
                cov = []
                for y in [c.top + 2, cy, c.bottom - 2]:
                    p = base_path_at(y)
                    if p and p not in cov: cov.append(p)
                if len(cov) > 1:
                    common = []
                    for parts in zip(*cov):
                        if len(set(parts)) == 1: common.append(parts[0])
                        else: break
                    if common: cov = [common]
            else:
                zone = '枠外'; head = ''
                path = left_path(c, cy, 0); cov = []
            MK = r'(イ|ロ|ハ|ニ|ホ|ヘ|ト|\(\d+\)|\([一二三四五六七八九十]+\)|[①-⑳])'
            m0 = re.match(r'^(.+?)' + MK + r'\s*$', clean(rows[0]['label'])) if len(rows) > 1 else None
            if m0 and not re.search(MK, m0.group(1)):
                pre = m0.group(1)
                for r in rows[1:]:
                    lab = clean(r['label'])
                    if re.match(r'^[/\s]*' + MK + r'\s*$', lab): r['label'] = pre + re.sub(r'^[/\s]*', '', lab)
            for r in rows:
                seg = c.seq[r['s']:r['e']]
                lab_chars = c.seq[max(0, r['s'] - len(r['label'])):r['s']]
                red = any(C.is_red(ch) for ch in seg) or any(C.is_red(ch) for ch in lab_chars if ch['text'].strip())
                pth = path
                if zone == '枠外' and not path and r is not rows[0] and clean(rows[0]['label']):
                    pth = [clean(rows[0]['label'])]
                out.append(dict(page=pno, service=svc, zone=zone, header=head, path=pth, label=clean(r['label']), cond=r['cond'], note=r['note'],
                                expr=clean(''.join(C.N(ch['text']) for ch in seg)), toks=[x[2] for x in r['toks']],
                                cover=cov, red=red, x=round(seg[0]['x0'], 1) if seg else c.x0, y=round(seg[0]['top'], 1) if seg else c.top,
                                cell=c.bbox, rest=clean(rest) if r is rows[-1] else ''))
        # 同じ行帯(注欄)にある「定員○人」ラベルを、その行帯の他の注欄の値にも付与
        prow = [o for o in out if o['page'] == pno and o['zone'] == '注欄']
        bands = {}
        TEI = re.compile(r'定員が?\d+人(以上\d+人以下|以上|以下)?(の場合)?')
        for o in prow:
            m = TEI.search(o['label'])
            if m: bands.setdefault((round(o['cell'][1]), round(o['cell'][3])), m.group(0))
        for o in prow:
            b = bands.get((round(o['cell'][1]), round(o['cell'][3])))
            o['band'] = b if b and not TEI.search(o['label']) else ''
        # 継続用: 各列(x範囲)の最下段ラベルを記録
        for c in body:
            key = (round(c.x0), round(c.x1)); lab = label_of(c)
            if lab and c.top >= carry.get(('_y',) + key, -1):
                carry[key] = lab; carry[('_y',) + key] = c.top
        for k in [k for k in carry if k[0] == '_y']: carry[k] = -1
        diag.append(dict(page=pno, svc=svc, hdr=bool(notes), mb=main_bottom, main=(round(mt) if main_bottom else None, round(main_bottom) if main_bottom else None)))
    return out, diag

if __name__ == '__main__':
    out, diag = run(sys.argv[1])
    json.dump(dict(rows=out, diag=diag, pagebase=pagebase), open(sys.argv[2], 'w'), ensure_ascii=False)
    for d in diag: print(d)
    print(len(out))
